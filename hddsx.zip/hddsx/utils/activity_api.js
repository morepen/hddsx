/**
 * 接口定义
 */

//仅为本机测试地址   对应node_test/app.js
const serverHost = 'http://127.0.0.0.1:8090/'

const activity_upFiles = {
  url: serverHost + 'adddata'
};


export {
  activity_upFiles,
};